﻿using DevExpress.XtraEditors;
using hamzITech.NewFolder1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hamzITech.FormProject.Purchase.Purchase
{
    public partial class Purchase : DevExpress.XtraEditors.XtraForm
    {
        public Purchase()
        {
            InitializeComponent();
        }

        private void dateEdit1_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void labelControl1_Click(object sender, EventArgs e)
        {

        }

        private void Purchase_Load(object sender, EventArgs e)
        {

        }




        public void Loadddl()
        {
            //DataSet Company = DatabaseConnection.SeclectQuery("select[ItemId],[Description] from Setup.Item");
            //gvdItemDescription.Properties.DataSource = Company.Tables[0];
            //ddlCompany.Properties.DisplayMember = "Description";
            //ddlCompany.Properties.ValueMember = "ItemId";

            



        }



        }
}