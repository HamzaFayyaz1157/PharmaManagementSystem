﻿
namespace hamzITech.FormProject.Purchase.Purchase
{
    partial class Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.btnClear = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.btnsaveandNew = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.ddlCompany = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.searchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.dateEdit1 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtItemId = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtretailPrice = new DevExpress.XtraEditors.TextEdit();
            this.gvdPurchaseInvoice = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gvdDescription = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemGridLookUpEdit2View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gvdItemItemId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdItemDescription = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdItmRetailPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdItemTradePrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdItemDiscount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdValue = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdTargetQty = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdstartDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdEndDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gvdRemark = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemGridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ddlCompany.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtretailPrice.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvdPurchaseInvoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit2View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AllowDropDownWhenReadOnly = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "Value",
            "Percentage"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.btnClear);
            this.panelControl2.Controls.Add(this.btnClose);
            this.panelControl2.Controls.Add(this.btnSave);
            this.panelControl2.Controls.Add(this.btnsaveandNew);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl2.Location = new System.Drawing.Point(0, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(668, 23);
            this.panelControl2.TabIndex = 2;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(240, 0);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(61, 23);
            this.btnClear.TabIndex = 4;
            this.btnClear.TabStop = false;
            this.btnClear.Text = "Clear";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(179, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(61, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.TabStop = false;
            this.btnClose.Text = "Close";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(91, 0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(89, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.TabStop = false;
            this.btnSave.Text = "Save && Close";
            // 
            // btnsaveandNew
            // 
            this.btnsaveandNew.Location = new System.Drawing.Point(-1, 0);
            this.btnsaveandNew.Name = "btnsaveandNew";
            this.btnsaveandNew.Size = new System.Drawing.Size(93, 23);
            this.btnsaveandNew.TabIndex = 1;
            this.btnsaveandNew.TabStop = false;
            this.btnsaveandNew.Text = " Save && New";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(16, 36);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(34, 13);
            this.labelControl4.TabIndex = 3;
            this.labelControl4.Text = "Vendor";
            // 
            // ddlCompany
            // 
            this.ddlCompany.Location = new System.Drawing.Point(58, 34);
            this.ddlCompany.Name = "ddlCompany";
            this.ddlCompany.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ddlCompany.Properties.NullText = "";
            this.ddlCompany.Properties.PopupView = this.searchLookUpEdit1View;
            this.ddlCompany.Size = new System.Drawing.Size(255, 20);
            this.ddlCompany.TabIndex = 4;
            // 
            // searchLookUpEdit1View
            // 
            this.searchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchLookUpEdit1View.Name = "searchLookUpEdit1View";
            this.searchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // dateEdit1
            // 
            this.dateEdit1.EditValue = null;
            this.dateEdit1.Location = new System.Drawing.Point(420, 35);
            this.dateEdit1.Name = "dateEdit1";
            this.dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Size = new System.Drawing.Size(112, 20);
            this.dateEdit1.TabIndex = 5;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(342, 39);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(70, 13);
            this.labelControl1.TabIndex = 6;
            this.labelControl1.Text = "Purchase Date";
            this.labelControl1.Click += new System.EventHandler(this.labelControl1_Click);
            // 
            // txtItemId
            // 
            this.txtItemId.Location = new System.Drawing.Point(58, 62);
            this.txtItemId.Name = "txtItemId";
            this.txtItemId.Properties.ReadOnly = true;
            this.txtItemId.Size = new System.Drawing.Size(115, 20);
            this.txtItemId.TabIndex = 9;
            this.txtItemId.TabStop = false;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(22, 65);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(25, 13);
            this.labelControl3.TabIndex = 8;
            this.labelControl3.Text = "PO #";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(191, 65);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(41, 13);
            this.labelControl7.TabIndex = 11;
            this.labelControl7.Text = "Remarks";
            // 
            // txtretailPrice
            // 
            this.txtretailPrice.Location = new System.Drawing.Point(252, 62);
            this.txtretailPrice.Name = "txtretailPrice";
            this.txtretailPrice.Properties.BeepOnError = false;
            this.txtretailPrice.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtretailPrice.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.txtretailPrice.Properties.MaskSettings.Set("mask", "f");
            this.txtretailPrice.Size = new System.Drawing.Size(280, 20);
            this.txtretailPrice.TabIndex = 10;
            // 
            // gvdPurchaseInvoice
            // 
            this.gvdPurchaseInvoice.Location = new System.Drawing.Point(-1, 110);
            this.gvdPurchaseInvoice.MainView = this.gridView1;
            this.gvdPurchaseInvoice.Name = "gvdPurchaseInvoice";
            this.gvdPurchaseInvoice.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemGridLookUpEdit1,
            this.repositoryItemLookUpEdit1,
            this.repositoryItemGridLookUpEdit2});
            this.gvdPurchaseInvoice.Size = new System.Drawing.Size(669, 408);
            this.gvdPurchaseInvoice.TabIndex = 12;
            this.gvdPurchaseInvoice.UseEmbeddedNavigator = true;
            this.gvdPurchaseInvoice.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gvdDescription,
            this.gvdValue,
            this.gvdTargetQty,
            this.gvdstartDate,
            this.gvdEndDate,
            this.gvdRemark});
            this.gridView1.GridControl = this.gvdPurchaseInvoice;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDownFocused;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gvdDescription
            // 
            this.gvdDescription.Caption = "Product";
            this.gvdDescription.ColumnEdit = this.repositoryItemGridLookUpEdit2;
            this.gvdDescription.FieldName = "Description";
            this.gvdDescription.Name = "gvdDescription";
            this.gvdDescription.Visible = true;
            this.gvdDescription.VisibleIndex = 0;
            // 
            // repositoryItemGridLookUpEdit2
            // 
            this.repositoryItemGridLookUpEdit2.AutoHeight = false;
            this.repositoryItemGridLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEdit2.Name = "repositoryItemGridLookUpEdit2";
            this.repositoryItemGridLookUpEdit2.PopupView = this.repositoryItemGridLookUpEdit2View;
            // 
            // repositoryItemGridLookUpEdit2View
            // 
            this.repositoryItemGridLookUpEdit2View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gvdItemItemId,
            this.gvdItemDescription,
            this.gvdItmRetailPrice,
            this.gvdItemTradePrice,
            this.gvdItemDiscount});
            this.repositoryItemGridLookUpEdit2View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit2View.Name = "repositoryItemGridLookUpEdit2View";
            this.repositoryItemGridLookUpEdit2View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit2View.OptionsView.ShowGroupPanel = false;
            // 
            // gvdItemItemId
            // 
            this.gvdItemItemId.Caption = "Item Id";
            this.gvdItemItemId.FieldName = "ItemId";
            this.gvdItemItemId.Name = "gvdItemItemId";
            this.gvdItemItemId.Visible = true;
            this.gvdItemItemId.VisibleIndex = 0;
            // 
            // gvdItemDescription
            // 
            this.gvdItemDescription.Caption = "Description";
            this.gvdItemDescription.FieldName = "Description";
            this.gvdItemDescription.Name = "gvdItemDescription";
            this.gvdItemDescription.Visible = true;
            this.gvdItemDescription.VisibleIndex = 1;
            // 
            // gvdItmRetailPrice
            // 
            this.gvdItmRetailPrice.Caption = "Retail Price";
            this.gvdItmRetailPrice.FieldName = "RetailPrice";
            this.gvdItmRetailPrice.Name = "gvdItmRetailPrice";
            this.gvdItmRetailPrice.Visible = true;
            this.gvdItmRetailPrice.VisibleIndex = 2;
            // 
            // gvdItemTradePrice
            // 
            this.gvdItemTradePrice.Caption = "Trade Price";
            this.gvdItemTradePrice.FieldName = "TradePrice";
            this.gvdItemTradePrice.Name = "gvdItemTradePrice";
            this.gvdItemTradePrice.Visible = true;
            this.gvdItemTradePrice.VisibleIndex = 3;
            // 
            // gvdItemDiscount
            // 
            this.gvdItemDiscount.Caption = "Item Discount";
            this.gvdItemDiscount.FieldName = "ItemDiscount";
            this.gvdItemDiscount.Name = "gvdItemDiscount";
            this.gvdItemDiscount.Visible = true;
            this.gvdItemDiscount.VisibleIndex = 4;
            // 
            // gvdValue
            // 
            this.gvdValue.Caption = "Sale Tax Item";
            this.gvdValue.FieldName = "Value";
            this.gvdValue.Name = "gvdValue";
            this.gvdValue.Visible = true;
            this.gvdValue.VisibleIndex = 1;
            this.gvdValue.Width = 60;
            // 
            // gvdTargetQty
            // 
            this.gvdTargetQty.Caption = "Target Qty";
            this.gvdTargetQty.FieldName = "TargetQty";
            this.gvdTargetQty.Name = "gvdTargetQty";
            this.gvdTargetQty.Visible = true;
            this.gvdTargetQty.VisibleIndex = 2;
            this.gvdTargetQty.Width = 65;
            // 
            // gvdstartDate
            // 
            this.gvdstartDate.Caption = "Start Date";
            this.gvdstartDate.ColumnEdit = this.repositoryItemDateEdit1;
            this.gvdstartDate.DisplayFormat.FormatString = "d";
            this.gvdstartDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gvdstartDate.FieldName = "StartDate";
            this.gvdstartDate.Name = "gvdstartDate";
            this.gvdstartDate.Visible = true;
            this.gvdstartDate.VisibleIndex = 3;
            this.gvdstartDate.Width = 65;
            // 
            // gvdEndDate
            // 
            this.gvdEndDate.Caption = "End Date";
            this.gvdEndDate.ColumnEdit = this.repositoryItemDateEdit2;
            this.gvdEndDate.FieldName = "EndDate";
            this.gvdEndDate.Name = "gvdEndDate";
            this.gvdEndDate.Visible = true;
            this.gvdEndDate.VisibleIndex = 4;
            this.gvdEndDate.Width = 67;
            // 
            // gvdRemark
            // 
            this.gvdRemark.Caption = "Remarks";
            this.gvdRemark.FieldName = "Remarks";
            this.gvdRemark.Name = "gvdRemark";
            this.gvdRemark.Visible = true;
            this.gvdRemark.VisibleIndex = 5;
            this.gvdRemark.Width = 145;
            // 
            // repositoryItemGridLookUpEdit1
            // 
            this.repositoryItemGridLookUpEdit1.AutoHeight = false;
            this.repositoryItemGridLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEdit1.Name = "repositoryItemGridLookUpEdit1";
            this.repositoryItemGridLookUpEdit1.PopupView = this.repositoryItemGridLookUpEdit1View;
            // 
            // repositoryItemGridLookUpEdit1View
            // 
            this.repositoryItemGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit1View.Name = "repositoryItemGridLookUpEdit1View";
            this.repositoryItemGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            // 
            // Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(668, 516);
            this.Controls.Add(this.gvdPurchaseInvoice);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.txtretailPrice);
            this.Controls.Add(this.txtItemId);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.dateEdit1);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.ddlCompany);
            this.Controls.Add(this.panelControl2);
            this.Name = "Purchase";
            this.Text = "Purchase";
            this.Load += new System.EventHandler(this.Purchase_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ddlCompany.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtretailPrice.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvdPurchaseInvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit2View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton btnClear;
        private DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraEditors.SimpleButton btnsaveandNew;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.SearchLookUpEdit ddlCompany;
        private DevExpress.XtraGrid.Views.Grid.GridView searchLookUpEdit1View;
        private DevExpress.XtraEditors.DateEdit dateEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtItemId;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtretailPrice;
        private DevExpress.XtraGrid.GridControl gvdPurchaseInvoice;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gvdValue;
        private DevExpress.XtraGrid.Columns.GridColumn gvdTargetQty;
        private DevExpress.XtraGrid.Columns.GridColumn gvdstartDate;
        private DevExpress.XtraGrid.Columns.GridColumn gvdEndDate;
        private DevExpress.XtraGrid.Columns.GridColumn gvdRemark;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEdit1;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gvdDescription;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEdit2;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit2View;
        private DevExpress.XtraGrid.Columns.GridColumn gvdItemItemId;
        private DevExpress.XtraGrid.Columns.GridColumn gvdItemDescription;
        private DevExpress.XtraGrid.Columns.GridColumn gvdItmRetailPrice;
        private DevExpress.XtraGrid.Columns.GridColumn gvdItemTradePrice;
        private DevExpress.XtraGrid.Columns.GridColumn gvdItemDiscount;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
    }
}